#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include<assert.h>
#include<stdbool.h>
#include<string.h>
#include"free_research.h"

bus_t* bus_new();
void bus_register(bus_t* b, int* identifier, int i);
void quest_add_bus(bus_t* b, int* identifier, int i);
void add_bus_register(bus_t* b, int* identifier, int i);
void collect_person(bus_t* b, int* identifier, int* person, int first_bus, int last_bus, int opp_loss, int time);
void bus_print(bus_t* b);
void profits_cal_print(bus_t* b, int opp_loss, int pass_time);
int Getrandom(int i);
void time_printer(int i);
void simulation(bus_t* b, int times, int* identifier);



int main(void) {
  srand((unsigned)time(NULL));
  int identifier;
  int j, i, first_bus, last_bus;
  int person=0;
  int opp_loss=0;

  //バス列初期化
  bus_t* b = bus_new();

  //traceモード
  for(i=0; i<=12; i++) {
    //この群で行列の生成
    person = person + ((int)Getrandom(i));
    time_printer(i);
    for(j=1; j<=(person/10); j++) printf("|");
    printf(" %d人\n", person);

    //ここでバスを追加するかどうか聞きそれに対応してバス列追加
    first_bus = b->bus_size; //この変数はバスを追加していく際に最初のバスが何番目だったかを確保するため
    bus_register(b, &identifier, i);
    last_bus = b->bus_size; //

    //返事がstopならシミュレーション停止、それ以外ならバスが人を回収
    collect_person(b, &identifier, &person, first_bus, last_bus, opp_loss, i);

    //回収後の残り待ち行列の積分 これの合計値が機会損失になる
    opp_loss += person;

    //この群で回収後の行列の生成
    time_printer(i);
    for(j=1; j<=(person/10); j++) printf("|");
    printf("　%d人\n\n", person);
    sleep(0);
  }
  bus_print(b);
  //費用,機会損失,利益の算出,更に出力
  profits_cal_print(b, opp_loss, i);

  //シミュレーションモード
  simulation(b, 10, &identifier);
}


void simulation(bus_t* b, int times, int* identifier) {
  int person, opp_loss, i, j;
  *identifier = TRACE;
  for(i=0; i<times; i++) {
    person=0;
    opp_loss=0;
    for(j=0; j<=12; j++) {
      person = person + ((int)Getrandom(j));

      collect_person(b, identifier, &person, 0, 0, opp_loss, j);
      /*while(b->bus[k].pass_time==j && k<(b->bus_size)) {
        if(person>=b->bus[k].capasity) {person -= b->bus[k].capasity;}
        else {person=0;}
        k++;
      }*/
      opp_loss += person;
    }
    profits_cal_print(b, opp_loss, j);
  }
}


int Getrandom(int i) {
  int f = i*i;
  if(i==0) return 0;
  else {return ((int)f + (rand()%(f)));}
}


void time_printer(int i) {
  //i1メモリで5分
  //15時からスタート
  int h, m;
  h = (i*5)/60;
  m = (i*5)%60;
  if(m<10) printf("%d:0%d ", 15+h, 0+m);
  else printf("%d:%d ", 15+h, 0+m);
}


bus_t* bus_new() {
  bus_t* b = (bus_t* )malloc(sizeof(bus_t));
  assert(b!=NULL);
  b->bus_size=0;
  return b;
}


void bus_register(bus_t* b, int* identifier, int i) {
  char bus[5];

  printf("どのバスを出しますか?(A/B/no/stop)---");
  scanf("%s", bus);

  if(bus[0]=='A' && bus[1]=='\0') {
    strcpy(b->bus[b->bus_size].which_bus, bus);
    b->bus[b->bus_size].pass_time=i;
    b->bus[b->bus_size].capasity=100;
    b->bus[b->bus_size].profits=5;
    b->bus[b->bus_size].cost=140;
    b->bus[b->bus_size].riding_time=5;
    (b->bus_size)++;
    *identifier = RIDE;
  }
  else if(bus[0]=='B' && bus[1]=='\0') {
    strcpy(b->bus[b->bus_size].which_bus, bus);
    b->bus[b->bus_size].pass_time=i;
    b->bus[b->bus_size].capasity=150;
    b->bus[b->bus_size].profits=7;
    b->bus[b->bus_size].cost=210;
    b->bus[b->bus_size].riding_time=10;
    (b->bus_size)++;
    *identifier = RIDE;
  }
  else if(strncmp(bus, "no\0", 3)==0) {*identifier = NORIDE;}
  else if(strncmp(bus, "stop\0", 5)==0) {*identifier = STOP;}
  else {
    printf("A/B/no/stop のどれかにしてください! ");
    bus_register(b, identifier, i);
  }

  //バスの追加
  if(*identifier==RIDE) {quest_add_bus(b, identifier, i);}
  else {;}
}


void quest_add_bus(bus_t* b, int* identifier, int i) {
  char reply[4];

  printf("バスを追加しますか?(yes/no)---");
  scanf("%s", reply);
  if(strncmp(reply, "no\0", 3)==0) {;}
  else if(strncmp(reply, "yes\0", 4)==0) {add_bus_register(b, identifier, i);}
  else {
    printf("yes/no のどれかにしてください! ");
    quest_add_bus(b, identifier, i);
  }
}


void add_bus_register(bus_t* b, int* identifier, int i) {
  char bus[2];
  printf("どちらのバスを出しますか?(A/B)---");
  scanf("%s", bus);

  if(strcmp(bus, "A\0")==0) {
    strcpy(b->bus[b->bus_size].which_bus, bus);
    b->bus[b->bus_size].pass_time=i;
    b->bus[b->bus_size].capasity=100;
    b->bus[b->bus_size].profits=5;
    b->bus[b->bus_size].cost=140;
    b->bus[b->bus_size].riding_time=5;
    (b->bus_size)++;
    *identifier = ADD;
    quest_add_bus(b, identifier, i);
  }
  else if(strcmp(bus, "B\0")==0) {
    strcpy(b->bus[b->bus_size].which_bus, bus);
    b->bus[b->bus_size].pass_time=i;
    b->bus[b->bus_size].capasity=150;
    b->bus[b->bus_size].profits=7;
    b->bus[b->bus_size].cost=210;
    b->bus[b->bus_size].riding_time=10;
    (b->bus_size)++;
    *identifier = ADD;
    quest_add_bus(b, identifier, i);
  }
  else {
    printf("A/B のどちらかにしてください! ");
    add_bus_register(b, identifier, i);
  }
}


void collect_person(bus_t* b, int* identifier, int* person, int first_bus, int last_bus, int opp_loss, int time) {
  int i;
  int x;

  if(*identifier==RIDE) {
    if(b->bus[first_bus].capasity<=(*person)) {
      *person = ((*person)-(b->bus[first_bus].capasity));
      b->bus[first_bus].occupancy=1;
    }
    else {
      b->bus[first_bus].occupancy = (*person)/(double)(b->bus[first_bus].capasity);
      (*person) = 0;
    }
  }
  else if(*identifier==ADD) {
    for(i=first_bus; i<last_bus; i++) {
      if(b->bus[i].capasity<=(*person)) {
        *person = ((*person)-(b->bus[i].capasity));
        b->bus[i].occupancy=1;
        //printf("%d %d\n", *person, b->bus[i].capasity);
      }
      else {
        b->bus[i].occupancy = (*person)/(double)(b->bus[i].capasity);
        *person = 0;
        //printf("%d %d\n", *person, b->bus[i].capasity);
      }
    }
  }
  else if(*identifier==NORIDE) {;}
  else if(*identifier==TRACE) {
    if(time==0) {x=0;}
    else {;}
    while(b->bus[x].pass_time==time) {
      if(b->bus[x].capasity<=(*person)) {
        *person = ((*person)-(b->bus[x].capasity));
        b->bus[x].occupancy=1;
      }
      else {
        b->bus[x].occupancy = (*person)/(double)(b->bus[x].capasity);
        *person = 0;
      }
      x++;
    }
    //printf("%d   %d   %d   %d   %.2lf\n", x, time, b->bus[x].pass_time, *person, b->bus[x-1].occupancy);
  }
  else {
    bus_print(b);
    profits_cal_print(b, opp_loss, time);
    exit(0);
  }
}


void bus_print(bus_t* b) {
  int size = b->bus_size;
  if(size>0) {
    printf("選択された1~%d番目のバスの内容は>>>\n", size);
    printf("出発時間  　バス    人数制限　利益　 出す費用   搭乗時間   乗車率\n");
    for(int i=0; i<size; i++) {
      printf("%d   ", i+1);
      time_printer(b->bus[i].pass_time);
      printf("      %s 　　　%d       %d    %d        %d   %f\n", b->bus[i].which_bus, b->bus[i].capasity, b->bus[i].profits, b->bus[i].cost, b->bus[i].riding_time, b->bus[i].occupancy);
    }
  }
  else {printf("まだバスが登録されていません\n");}
}


void profits_cal_print(bus_t* b, int opp_loss, int pass_time) {
double profit_sum=0.0;
int cost_sum=0;
int stress=0;

  for(int i=0; i<(b->bus_size); i++) {
    profit_sum += ((double)(b->bus[i].profits*b->bus[i].occupancy));
    cost_sum += (b->bus[i].cost);
    if(b->bus[i].occupancy>=0.5) stress += ((int)100*(b->bus[i].occupancy-0.5));
    else ;
  }
  printf("平均機会損失    平均ストレス　　　費用      利益\n");
  printf("%.2lf           %.2lf             %d        %.2lf\n", ((double)opp_loss/pass_time), ((double)stress/pass_time), cost_sum, profit_sum);
}
